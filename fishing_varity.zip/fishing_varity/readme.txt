- What is this?
 This is the fishing varity mod pack for minetest.

- Notes:
 There are 9 mods to choose from. Only one should be chosen.
 Chat messages let you know what you've cought!

- "fishing" Mod:
 can catch: (including fish)
  player bones, stick, papyrus, glass bottle
 worms crafting recipie:
  [ dirt | dirt ]
  [ dirt | dirt ]
 rod crafting recipie:
  [ empty | empty | stick ]
  [ empty | stick | wool  ]
  [ stick | empty | empty ]
 worms per craft:
  1
 dependancies:
  default

- "fishing_depends" Mod:
 can catch: (including fish)
  player bones, stick, papyrus, glass bottle, string, cotton, rope, lucky block.
 worms crafting recipie:
  [ dirt | dirt ]
  [ dirt | dirt ]
 rod crafting recipie:
  [ empty | empty | stick  ]
  [ empty | stick | string ]
  [ stick | empty | string ]
 worms per craft:
  1
 dependancies:
  default
  farming
  xdecor
  lucky_block

- "fishing_farming" Mod:
 can catch: (including fish)
  player bones, stick, papyrus, glass bottle, string, cotton
 worms crafting recipie:
  [ dirt | dirt ]
  [ dirt | dirt ]
 rod crafting recipie:
  [ empty | empty | stick  ]
  [ empty | stick | string ]
  [ stick | empty | string ]
 worms per craft:
  1
 dependancies:
  default
  farming

- "fishing_easy' Mod:
 can catch: (including fish)
  player bones, stick, papyrus, glass bottle
 worms crafting recipie:
  [ grass ]
 rod crafting recipie:
  [ empty | empty | stick ]
  [ empty | stick | wool  ]
  [ stick | empty | empty ]
 worms per craft:
  1
 dependancies:
  default

- "fishing_easy_depends" Mod:
 can catch: (including fish)
  player bones, stick, papyrus, glass bottle, string, cotton, rope, lucky block.
 worms crafting recipie:
  [ grass ]
 rod crafting recipie:
  [ empty | empty | stick  ]
  [ empty | stick | string ]
  [ stick | empty | string ]
 worms per craft:
  1
 dependancies:
  default
  farming
  xdecor
  lucky_block

- "fishing_easy_farming" Mod:
 can catch: (including fish)
  player bones, stick, papyrus, glass bottle, string, cotton
 worms crafting recipie:
  [ grass ]
 rod crafting recipie:
  [ empty | empty | stick  ]
  [ empty | stick | string ]
  [ stick | empty | string ]
 worms per craft:
  1
 dependancies:
  default
  farming

- "fishing_super_easy" Mod:
 can catch: (including fish) (100% catch rate)
  player bones, stick, papyrus, glass bottle
 worms crafting recipie:
  [ grass ]
 rod crafting recipie:
  [ empty | empty | stick ]
  [ empty | stick | wool  ]
  [ stick | empty | empty ]
 worms per craft:
  33
 dependancies:
  default

- "fishing_super_easy_depends" Mod:
 can catch: (including fish) (100% catch rate)
  player bones, stick, papyrus, glass bottle, string, cotton, rope, lucky block.
 worms crafting recipie:
  [ grass ]
 rod crafting recipie:
  [ empty | empty | stick ]
  [ empty | stick | wool  ]
  [ stick | empty | empty ]
 worms per craft:
  33
 dependancies:
  default
  farming
  xdecor
  lucky_block

 - "fishing_super_easy_farming" Mod:
 can catch: (including fish) (100% catch rate)
  player bones, stick, papyrus, glass bottle, string, cotton
 worms crafting recipie:
  [ grass ]
 rod crafting recipie:
  [ empty | empty | stick  ]
  [ empty | stick | string ]
  [ stick | empty | string ]
 worms per craft:
  33
 dependancies:
  default
  farming
