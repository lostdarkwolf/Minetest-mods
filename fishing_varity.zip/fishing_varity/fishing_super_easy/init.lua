
-- Raw Fish (Thanks to Altairas for her Fish image on DeviantArt)
minetest.register_craftitem("fishing_super_easy:fish_raw", {
	description = "Raw Fish",
	inventory_image = "fish_raw.png",
	on_use = minetest.item_eat(2),
})

-- Cooked Fish
minetest.register_craftitem("fishing_super_easy:fish_cooked", {
	description = "Cooked Fish",
	inventory_image = "fish_cooked.png",
	on_use = minetest.item_eat(5),
})

-- Worm
minetest.register_craftitem("fishing_super_easy:worm", {
	description = "Worm",
	inventory_image = "worm.png",
})

-- Fishing Rod
minetest.register_craftitem("fishing_super_easy:fishing_rod", {
	description = "Fishing Rod",
	inventory_image = "fishing_rod.png",
	stack_max = 1,
	liquids_pointable = true,
})

-- Fishing Rod (Baited)
minetest.register_craftitem("fishing_super_easy:fishing_rod_baited", {
	description = "Baited Fishing Rod",
	inventory_image = "fishing_rod_baited.png",
	wield_image = "fishing_rod_wield.png",
	stack_max = 1,
	liquids_pointable = true,
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing and pointed_thing.under then
			local node = minetest.env:get_node(pointed_thing.under)
			if string.find(node.name, "default:water_source") then
				local inv = user:get_inventory()
				if inv:room_for_item("main", {name="fishing_super_easy:fish_raw"}) then
					if math.random(1, 100) < 80 then
						inv:add_item("main", {name="fishing_super_easy:fish_raw"})
						minetest.chat_send_player(user:get_player_name(), "You cought a fish!")
					else
						local rand=math.floor(math.random(1, 4.999999));
						if rand==1 then
							inv:add_item("main", {name="bones:bones"})
							minetest.chat_send_player(user:get_player_name(), "You cought bones!")
						end
						if rand==2 then
							inv:add_item("main", {name="default:stick"})
							minetest.chat_send_player(user:get_player_name(), "You cought a stick!")								
						end
						if rand==3 then
							inv:add_item("main", {name="default:papyrus"})
							minetest.chat_send_player(user:get_player_name(), "You cought papyrus!")
						end
						if rand==4 then
							inv:add_item("main", {name="vessels:glass_bottle"})
							minetest.chat_send_player(user:get_player_name(), "You cought a glass bottle!")
						end
					end
				else
					minetest.chat_send_player(user:get_player_name(), "Your Fish Got Away! Inventory Too Full")
				end
			end
		end
	end,
})

-- Fishing Rod
minetest.register_craft({
	output = "fishing_super_easy:fishing_rod",
	recipe = {
			{"","","default:stick"},
			{"", "default:stick", "group:wool"},
			{"default:stick", "", ""},
		}
})

-- Sift through grass to find Worm
minetest.register_craft({
	output = "fishing_super_easy:worm 33",
	recipe = {
		{"group:grass"},
	}
})

-- Cooking Fish
minetest.register_craft({
	type = "cooking",
	output = "fishing_super_easy:fish_cooked",
	recipe = "fishing_super_easy:fish_raw",
	cooktime = 2,
})

-- Baiting Fishing Rod
minetest.register_craft({
	type = "shapeless",
	output = "fishing_super_easy:fishing_rod_baited",
	recipe = {"fishing_super_easy:fishing_rod", "fishing_super_easy:worm"},
})

